import { Component } from '@angular/core';
import { ClarityModule } from '@clr/angular';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TPS2 Monitoring';
  columnHeaders: string[] = [];
  constructor(){
    var json = { 
      "status": 200,
      "success": true,
      "result": [
        { 
            "Dribbble": 'a',
            "Behance": '',
            "Blog": 'http://blog.invisionapp.com/reimagine-web-design-process/',
            "Youtube": '',
            "Vimeo": '' 
        },
        { 
           "Dribbble": '',
           "Behance": '',
           "Blog": 'http://creative.mailchimp.com/paint-drips/?_ga=1.32574201.612462484.1431430487',
           "Youtube": '',
           "Vimeo": '' } 
      ] 
    };
    
 
    var results = json["result"];
    if (results.length > 0){ 
      var columnsIn = results[0]; 
      for(var key in columnsIn){
        this.columnHeaders.push(key);
        console.log(key); // here is your column name you are looking for
      } 
    }else{
        console.log("No columns");
    }
  
  }
  
}
